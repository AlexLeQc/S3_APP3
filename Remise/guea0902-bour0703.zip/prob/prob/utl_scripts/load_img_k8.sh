minikube image unload a6-client a6-serveur a6-gestionnaire
minikube image load a6-client a6-serveur a6-gestionnaire