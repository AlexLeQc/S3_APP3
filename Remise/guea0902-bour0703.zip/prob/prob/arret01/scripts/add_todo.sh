#!/bin/sh

cd /todo
touch todo.txt
python3 /usr/local/bin/todo.py -U -r
