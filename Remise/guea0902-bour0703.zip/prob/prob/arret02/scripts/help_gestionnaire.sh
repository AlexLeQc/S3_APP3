#!/bin/sh

echo "Commandes simplifiées disponibles:"
echo "  liste"
echo "  liste_std"
echo ""
echo "Pour des commandes plus complexes, voir aussi /usr/local/bin/listTodo.py: "
echo "  (accessible directement par la commande liste_std)"
python3 /usr/local/bin/listTodo.py --help
