#!/bin/sh

python3 /usr/local/bin/callTodo.py -i
