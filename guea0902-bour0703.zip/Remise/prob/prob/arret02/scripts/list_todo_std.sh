#!/bin/sh

python3 /usr/local/bin/listTodo.py $@
