#!/bin/bash

docker build -t todo-base -f ../base_img/Dockerfile ../base_img/