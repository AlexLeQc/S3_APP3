#!/bin/sh

docker build -t arret01 .
