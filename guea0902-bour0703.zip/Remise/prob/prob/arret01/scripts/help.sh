#!/bin/sh

echo "Commandes simplifiées disponibles:"
echo "	nouveau"
echo "	retrait"
echo "	liste"
echo ""
echo "Pour des commandes plus complexes, voir aussi /usr/local/bin/todo.py: "
echo "  (accessible directement par la commande todo)"
python3 /usr/local/bin/todo.py --help
